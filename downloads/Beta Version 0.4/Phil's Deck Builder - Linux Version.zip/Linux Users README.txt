If you run Phil's Deck Builder and get the following error message in your browser window:

org.mozilla.browser.MozillaException: java.lang.UnsatisfiedLinkError: Unable to load library 'gtk-x11-2.0': libgtk-x11-2.0.so: cannot open shared object file: No such file or directory
�� at org.mozilla.browser.MozillaExecutor.mozInit(MozillaExecutor.java:220)
�� at org.mozilla.browser.MozillaInitialization.initialize(MozillaInitialization.java:143)
�� at org.mozilla.browser.MozillaPanel.<init>(MozillaPanel.java:147)
�� at org.mozilla.browser.MozillaPanel.<init>(MozillaPanel.java:116)
�� at DeckBuilder.WebBrowserPanel.<init>(WebBrowserPanel.java:59)
�� at DeckBuilder.MainWindow.initComponents(MainWindow.java:62)
�� at DeckBuilder.MainWindow.<init>(MainWindow.java:32)
�� at DeckBuilder.Main.main(Main.java:10)
Caused by: java.lang.UnsatisfiedLinkError: Unable to load library 'gtk-x11-2.0': libgtk-x11-2.0.so: cannot open shared object file: No such file or directory
�� at com.sun.jna.NativeLibrary.loadLibrary(NativeLibrary.java:114)
�� at com.sun.jna.NativeLibrary.getInstance(NativeLibrary.java:157)
�� at com.sun.jna.Library$Handler.<init>(Library.java:123)
�� at com.sun.jna.Native.loadLibrary(Native.java:260)
�� at com.sun.jna.Native.loadLibrary(Native.java:246)
�� at org.mozilla.browser.impl.jna.Gtk.<clinit>(Gtk.java:13)
�� at org.mozilla.browser.MozillaExecutor$1.run(MozillaExecutor.java:180)

Then you'll need to do the following:
	1.) Goto /usr/lib and find a file that looks like "libgtk-x11-2.0.so" (it won't exactly match--which is the problem).
	2.) Rename that file to "libgtk-x11-2.0.so" (you'll likely need administrative priveleges).
	3.) Run Phil's Deck Builder again.
	